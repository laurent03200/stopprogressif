package com.stopprogressif

import android.content.Context
import android.content.SharedPreferences

object TimerUtils {

    private const val PREFS_NAME = "TimerPrefs"
    private const val KEY_REMAINING_TIME = "remainingTime"

    fun saveRemainingTime(context: Context, remainingTime: Long) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_REMAINING_TIME, remainingTime).apply()
    }

    fun loadRemainingTime(context: Context): Long? {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return if (prefs.contains(KEY_REMAINING_TIME)) prefs.getLong(KEY_REMAINING_TIME, 0L) else null
    }
}
