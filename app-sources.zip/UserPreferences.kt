package com.stopprogressif

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extension pour créer un DataStore
val Context.dataStore by preferencesDataStore(name = "user_preferences")

class UserPreferences(private val context: Context) {

    companion object {
        val PRIX_PAQUET = floatPreferencesKey("prix_paquet")
        val CIGARETTES_PAR_JOUR = intPreferencesKey("cigarettes_par_jour")
        val OBJECTIF_CIGARETTES = intPreferencesKey("objectif_cigarettes")
    }

    // Lire les préférences
    val prixPaquetFlow: Flow<Float> = context.dataStore.data
        .map { preferences -> preferences[PRIX_PAQUET] ?: 0f }

    val cigarettesParJourFlow: Flow<Int> = context.dataStore.data
        .map { preferences -> preferences[CIGARETTES_PAR_JOUR] ?: 0 }

    val objectifCigarettesFlow: Flow<Int> = context.dataStore.data
        .map { preferences -> preferences[OBJECTIF_CIGARETTES] ?: 0 }

    // Sauvegarder les préférences
    suspend fun savePrixPaquet(value: Float) {
        context.dataStore.edit { preferences ->
            preferences[PRIX_PAQUET] = value
        }
    }

    suspend fun saveCigarettesParJour(value: Int) {
        context.dataStore.edit { preferences ->
            preferences[CIGARETTES_PAR_JOUR] = value
        }
    }

    suspend fun saveObjectifCigarettes(value: Int) {
        context.dataStore.edit { preferences ->
            preferences[OBJECTIF_CIGARETTES] = value
        }
    }
}
