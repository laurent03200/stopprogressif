package com.stopprogressif

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

@Composable
fun ModeSelector(
    selectedMode: String,
    onModeChange: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        listOf("objectif", "intermittence").forEach { mode ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.selectable(
                    selected = (mode == selectedMode),
                    onClick = { onModeChange(mode) },
                    role = Role.RadioButton
                )
            ) {
                RadioButton(
                    selected = (mode == selectedMode),
                    onClick = null
                )
                Text(
                    text = if (mode == "objectif") "Par Objectif" else "Par Intermittence",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
