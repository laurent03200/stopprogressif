package com.stopprogressif

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    progressViewModel: ProgressifViewModel = viewModel(factory = ProgressifViewModelFactory(LocalContext.current.applicationContext as Application))
) {
    val settings = progressViewModel.settingsData.collectAsState()

    var prixPaquet by remember { mutableStateOf(settings.value.prixPaquet.toString()) }
    var cigarettesParPaquet by remember { mutableStateOf(settings.value.cigarettesParPaquet.toString()) }
    var mode by remember { mutableStateOf(settings.value.mode) }
    var objectifParJour by remember { mutableStateOf(settings.value.objectifParJour.toString()) }
    var heuresEntreCigarettes by remember { mutableStateOf(settings.value.heuresEntreCigarettes.toString()) }
    var minutesEntreCigarettes by remember { mutableStateOf(settings.value.minutesEntreCigarettes.toString()) }
    var cigarettesHabituelles by remember { mutableStateOf(settings.value.cigarettesHabituelles.toString()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Paramètres", color = Color.White, fontSize = 20.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = prixPaquet,
                onValueChange = { prixPaquet = it },
                label = { Text("Prix du paquet (€)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = cigarettesParPaquet,
                onValueChange = { cigarettesParPaquet = it },
                label = { Text("Cigarettes par paquet") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            ModeSelector(
                selectedMode = mode,
                onModeChange = { mode = it }
            )

            if (mode == "objectif") {
                OutlinedTextField(
                    value = objectifParJour,
                    onValueChange = { objectifParJour = it },
                    label = { Text("Objectif cigarettes par jour") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = heuresEntreCigarettes,
                        onValueChange = { heuresEntreCigarettes = it },
                        label = { Text("Heures entre 2 cigarettes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minutesEntreCigarettes,
                        onValueChange = { minutesEntreCigarettes = it },
                        label = { Text("Minutes entre 2 cigarettes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            OutlinedTextField(
                value = cigarettesHabituelles,
                onValueChange = { cigarettesHabituelles = it },
                label = { Text("Cigarettes fumées habituellement") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    progressViewModel.saveSettings(
                        SettingsData(
                            prixPaquet = prixPaquet.toFloatOrNull() ?: 10f,
                            cigarettesParPaquet = cigarettesParPaquet.toIntOrNull() ?: 20,
                            mode = mode,
                            objectifParJour = objectifParJour.toIntOrNull() ?: 20,
                            heuresEntreCigarettes = heuresEntreCigarettes.toIntOrNull() ?: 1,
                            minutesEntreCigarettes = minutesEntreCigarettes.toIntOrNull() ?: 0,
                            cigarettesHabituelles = cigarettesHabituelles.toIntOrNull() ?: 30
                        )
                    )
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00BCD4),
                    contentColor = Color.White
                )
            ) {
                Text("Sauvegarder", fontSize = 18.sp)
            }
        }
    }
}
