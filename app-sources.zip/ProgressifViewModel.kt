package com.stopprogressif

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.max

class ProgressifViewModel(application: Application) : AndroidViewModel(application) {

    private val dataStoreManager = DataStoreManager(application)

    private val _settingsData = MutableStateFlow(dataStoreManager.loadSettings())
    val settingsData: StateFlow<SettingsData> = _settingsData

    private val _cigarettesFumees = MutableStateFlow(0)
    val cigarettesFumees: StateFlow<Int> = _cigarettesFumees

    private val _tempsRestant = MutableStateFlow(0L)
    val tempsRestant: StateFlow<Long> = _tempsRestant

    private val ecartsList = mutableListOf<Long>()
    private val _shouldSuggestAugmentation = MutableStateFlow(false)
    val shouldSuggestAugmentation: StateFlow<Boolean> = _shouldSuggestAugmentation

    private var isTimerRunning = false

    init {
        val (savedTemps, savedCigarettes, timestamp) = dataStoreManager.loadStateWithTimestamp()
        val now = System.currentTimeMillis()
        val ecart = now - timestamp

        val nouveauTemps = savedTemps - ecart
        _tempsRestant.value = nouveauTemps
        _cigarettesFumees.value = savedCigarettes

        startTimer()
    }

    fun saveSettings(newSettings: SettingsData) {
        dataStoreManager.saveSettings(newSettings)
        _settingsData.value = newSettings
        resetTimer()
    }

    private fun startTimer() {
        if (isTimerRunning) return
        isTimerRunning = true
        viewModelScope.launch {
            while (true) {
                delay(1000)
                decreaseTimer()
            }
        }
    }

    fun decreaseTimer() {
        val now = System.currentTimeMillis()
        val lastUpdate = dataStoreManager.getLastUpdateTime()
        val ecart = now - lastUpdate

        val newValue = _tempsRestant.value - ecart
        _tempsRestant.value = newValue
        dataStoreManager.saveStateWithTimestamp(newValue, _cigarettesFumees.value)
    }

    fun fumerUneCigarette() {
        val tempsPrevu = getInitialIntervalle()
        val tempsEcoule = tempsPrevu - _tempsRestant.value
        if (tempsEcoule > 15 * 60_000) {
            ecartsList.add(tempsEcoule)
            if (ecartsList.size >= 3) {
                _shouldSuggestAugmentation.value = true
                ecartsList.clear()
            }
        }
        _cigarettesFumees.value += 1
        resetTimer()
    }

    fun annulerDerniereCigarette() {
        if (_cigarettesFumees.value > 0) {
            _cigarettesFumees.value -= 1
        }
    }

    fun resetTimer() {
        val initial = getInitialIntervalle()
        _tempsRestant.value = initial
        dataStoreManager.saveStateWithTimestamp(initial, _cigarettesFumees.value)
    }

    fun getInitialIntervalle(): Long {
        val settings = _settingsData.value
        return if (settings.mode == "objectif") {
            val nombreCigarettes = max(1, settings.objectifParJour)
            val minutesParJour = 24 * 60
            (minutesParJour / nombreCigarettes) * 60_000L
        } else {
            val totalMinutes = settings.heuresEntreCigarettes * 60 + settings.minutesEntreCigarettes
            max(1, totalMinutes) * 60_000L
        }
    }

    fun clearSuggestionFlag() {
        _shouldSuggestAugmentation.value = false
    }
}
