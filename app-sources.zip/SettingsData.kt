package com.stopprogressif

data class SettingsData(
    val prixPaquet: Float = 10f,
    val cigarettesParPaquet: Int = 20,
    val mode: String = "objectif", // "objectif" ou "intermittence"
    val objectifParJour: Int = 20,
    val heuresEntreCigarettes: Int = 1,
    val minutesEntreCigarettes: Int = 0,
    val cigarettesHabituelles: Int = 30
)







