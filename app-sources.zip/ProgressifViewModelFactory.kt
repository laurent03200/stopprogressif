package com.stopprogressif

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class ProgressifViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProgressifViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProgressifViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
