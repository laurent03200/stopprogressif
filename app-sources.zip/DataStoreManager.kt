package com.stopprogressif

import android.content.Context
import android.content.SharedPreferences

class DataStoreManager(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun saveSettings(settingsData: SettingsData) {
        with(sharedPreferences.edit()) {
            putFloat("prixPaquet", settingsData.prixPaquet)
            putInt("cigarettesParPaquet", settingsData.cigarettesParPaquet)
            putString("mode", settingsData.mode)
            putInt("objectifParJour", settingsData.objectifParJour)
            putInt("heuresEntreCigarettes", settingsData.heuresEntreCigarettes)
            putInt("minutesEntreCigarettes", settingsData.minutesEntreCigarettes)
            putInt("cigarettesHabituelles", settingsData.cigarettesHabituelles)
            apply()
        }
    }

    fun loadSettings(): SettingsData {
        return SettingsData(
            prixPaquet = sharedPreferences.getFloat("prixPaquet", 10f),
            cigarettesParPaquet = sharedPreferences.getInt("cigarettesParPaquet", 20),
            mode = sharedPreferences.getString("mode", "objectif") ?: "objectif",
            objectifParJour = sharedPreferences.getInt("objectifParJour", 20),
            heuresEntreCigarettes = sharedPreferences.getInt("heuresEntreCigarettes", 1),
            minutesEntreCigarettes = sharedPreferences.getInt("minutesEntreCigarettes", 0),
            cigarettesHabituelles = sharedPreferences.getInt("cigarettesHabituelles", 30)
        )
    }

    // Sauvegarde améliorée avec timestamp
    fun saveStateWithTimestamp(tempsRestant: Long, cigarettesFumees: Int) {
        with(sharedPreferences.edit()) {
            putLong("tempsRestant", tempsRestant)
            putInt("cigarettesFumees", cigarettesFumees)
            putLong("lastUpdateTime", System.currentTimeMillis())
            apply()
        }
    }

    fun loadStateWithTimestamp(): Triple<Long, Int, Long> {
        val tempsRestant = sharedPreferences.getLong("tempsRestant", -1L)
        val cigarettesFumees = sharedPreferences.getInt("cigarettesFumees", 0)
        val lastUpdateTime = sharedPreferences.getLong("lastUpdateTime", System.currentTimeMillis())
        return Triple(tempsRestant, cigarettesFumees, lastUpdateTime)
    }

    // ➕ Cette fonction permet de récupérer uniquement le dernier timestamp enregistré
    fun getLastUpdateTime(): Long {
        return sharedPreferences.getLong("lastUpdateTime", System.currentTimeMillis())
    }
}

