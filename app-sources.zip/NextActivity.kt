package com.stopprogressif

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import com.stopprogressif.ui.theme.StopProgressifTheme
import androidx.compose.runtime.Composable


class NextActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StopProgressifTheme {
                Surface(
                    color = MaterialTheme.colorScheme.background
                ) {
                    Text("Vous êtes dans la prochaine activité ! 🎯")
                }
            }
        }
    }
}
