package com.stopprogressif

data class Settings(
    val prixPaquet: Float = 0f,
    val cigarettesParPaquet: Int = 20,
    val cigarettesHabituelles: Int = 20,
    val objectifParJour: Int = 20,
    val modeSevrage: String = "OBJECTIF", // Peut être "OBJECTIF" ou "ESPACEMENT"
    val espacementHeures: Int = 0,
    val espacementMinutes: Int = 0
)
